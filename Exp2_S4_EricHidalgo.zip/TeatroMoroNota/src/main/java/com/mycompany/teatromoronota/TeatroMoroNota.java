/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teatromoronota;

import java.util.Scanner;

/**@author EricHidalgo
 * 
 * @author erich
 */
public class TeatroMoroNota {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            OUTER:
            for (int i = 0; i < 1; i++) {
                System.out.println("Bienvenido al Teatro Moro");
                System.out.println("1. Comprar entrada");
                System.out.println("2. Salir");
                System.out.print("Seleccione una opcion: ");
                int opcion = scanner.nextInt();
                switch (opcion) {
                    case 1 -> {
                        boolean compraExitosa = false;
                        while (!compraExitosa) {
                            System.out.println("Seleccione la zona del asiento: ");
                            System.out.println("A. Zona A");
                            System.out.println("B. Zona B");
                            System.out.println("C. Zona C");
                            System.out.print("Ingrese su opcion: ");
                            char zona = scanner.next().charAt(0);
                            
                            if (zona != 'A' && zona != 'B' && zona != 'C') {
                                System.out.println("Opcion invalida. Intente nuevamente.");
                                continue;
                            }
                            
                            System.out.print("Ingrese su edad: ");
                            int edad = scanner.nextInt();
                            
                            if (edad <= 0 || edad > 120) {
                                System.out.println("Edad no valida. Intente nuevamente.");
                                continue;
                            }
                            
                            double precioBase = 0;
                            double descuento = 0;
                            
                            switch (zona) {
                                case 'A':
                                    precioBase = 5000;
                                    break;
                                case 'B':
                                    precioBase = 4000;
                                    break;
                                case 'C':
                                    precioBase = 3000;
                                    break;
                                default:
                                    break;
                            }
                            
                            if (edad <= 25) {
                                descuento = 0.10;
                            } else if (edad >= 60) {
                                descuento = 0.15;
                            }
                            
                            double precioFinal = precioBase - (precioBase * descuento);
                            
                            System.out.println("Resumen de la compra:");
                            System.out.println("Ubicacion del asiento: Zona " + zona);
                            System.out.println("Precio base: $" + precioBase);
                            System.out.println("Descuento aplicado: " + (descuento * 100) + "%");
                            System.out.println("Precio final a pagar: $" + precioFinal);
                            
                            compraExitosa = true;
                        }   System.out.print("¿Desea realizar otra compra? (S/N): ");
                        char continuar = scanner.next().charAt(0);
                        if (continuar == 'N' || continuar == 'n') {
                            System.out.println("Gracias por su compra. ¡Hasta pronto!");
                            break OUTER;
                        }
                    }
                    case 2 -> {
                        System.out.println("Gracias por visitarnos. ¡Hasta pronto!");
                        break OUTER;
                    }
                    default -> System.out.println("Opcion invalida. Intente nuevamente.");
                }
            }
        }
    }
}
